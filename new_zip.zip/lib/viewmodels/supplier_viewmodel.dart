// MVVM: ViewModel — business logic only
import 'dart:async';
import 'dart:io';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/material_model.dart';
import '../models/order_model.dart';
import '../models/rating_model.dart';
import '../models/transaction_model.dart';
import '../constants/app_constants.dart';
import '../models/company_model.dart';
import '../models/user_model.dart';
import '../models/invitation_model.dart';
import '../repositories/material_repository.dart';
import '../repositories/order_repository.dart';
import '../repositories/transaction_repository.dart';
import '../repositories/price_history_repository.dart';
import '../repositories/user_repository.dart';
import '../repositories/company_repository.dart';
import '../services/cloudinary_service.dart';
import '../services/storage_service.dart';
import '../services/cloud_function_service.dart';
import '../services/notification_service.dart';
import 'auth_viewmodel.dart';

enum SupplierStatus { unknown, pending, rejected, active }

class SupplierViewModel extends ChangeNotifier {
  final MaterialRepository _materialRepo;
  final OrderRepository _orderRepo;
  final TransactionRepository _transactionRepo;
  final StorageService _storageService;
  final UserRepository _userRepo;
  final CompanyRepository _companyRepo;
  final NotificationService _notificationService;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  SupplierViewModel(
    this._materialRepo,
    this._orderRepo,
    this._transactionRepo,
    this._storageService,
    PriceHistoryRepository _,
    CloudFunctionService __,
    this._userRepo,
    this._companyRepo,
    this._notificationService,
  );

  static String monthKey([DateTime? date]) =>
      DateFormat('yyyy-MM').format(date ?? DateTime.now());

  String? _supplierUid;
  String? _selectedCompanyId;
  String? _rejectionReason;
  String? _error;
  bool _isLoading = false;
  bool _appealSubmitted = false;

  List<MaterialModel> _materials = [];
  List<OrderModel> _orders = [];
  List<RatingModel> _ratings = [];
  List<TransactionModel> _transactions = [];
  List<CompanyModel> _companies = [];
  List<InvitationModel> _invitations = [];
  List<Map<String, dynamic>> _monthlyChart = [];
  List<MonthlyEarning> _monthlyEarnings = [];
  UserModel? _profile;
  String _status = 'pending';

  StreamSubscription? _statusSubscription;
  StreamSubscription? _companiesSubscription;
  StreamSubscription? _materialsSubscription;
  StreamSubscription? _ordersSubscription;
  StreamSubscription? _earningsSubscription;
  StreamSubscription? _invitationsSubscription;
  StreamSubscription? _ratingsSubscription;

  bool _isDashboardLoading = false;
  bool _companiesLoaded = false;
  bool _companiesLoadFailed = false;
  bool _materialsInitialized = false;
  bool _ordersInitialized = false;
  bool _earningsInitialized = false;
  bool _ratingsInitialized = false;

  // Dashboard Aggregates
  double totalEarnings = 0;
  double netEarnings = 0;
  double pendingEarnings = 0;
  double completedPayouts = 0;

  // Getters
  String? get supplierUid => _supplierUid;
  String? get selectedCompanyId => _selectedCompanyId;
  String? get rejectionReason => _rejectionReason;
  String? get error => _error;
  bool get isLoading => _isLoading;
  bool get isDashboardLoading => _isDashboardLoading;
  bool get companiesLoaded => _companiesLoaded;
  bool get companiesLoadFailed => _companiesLoadFailed;
  bool get appealSubmitted => _appealSubmitted;
  List<MaterialModel> get materials => _materials;
  List<OrderModel> get orders => _orders;
  List<RatingModel> get ratings => _ratings;
  List<TransactionModel> get transactions => _transactions;
  List<CompanyModel> get companies => _companies;
  List<InvitationModel> get invitations => _invitations;
  List<Map<String, dynamic>> get monthlyChart => _monthlyChart;
  List<MonthlyEarning> get monthlyEarnings => _monthlyEarnings;
  UserModel? get profile => _profile;
  String get status => _status;

  int get totalMaterialsCount => _materials.length;

  int get pendingOrdersCount => _orders.where((o) {
        final status = o.status.toLowerCase();
        return status == 'pending' || status == 'pending_approval';
      }).length;

  int get activeOrdersCount => _orders.where((o) {
        final status = o.status.toLowerCase();
        return status == 'accepted' || status == 'inprogress';
      }).length;

  int get inProgressOrdersCount => activeOrdersCount;

  int get ratingsCount => _ratings.length;

  List<OrderModel> get recentOrders {
    final sorted = List<OrderModel>.from(_orders)
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return sorted.take(5).toList();
  }

  List<MaterialModel> get recentMaterials {
    final sorted = List<MaterialModel>.from(_materials)
      ..sort((a, b) {
        final aDate = a.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
        final bDate = b.createdAt ?? DateTime.fromMillisecondsSinceEpoch(0);
        return bDate.compareTo(aDate);
      });
    return sorted.take(3).toList();
  }

  double get monthlyEarningsTotal {
    final settledFromTx = _transactions
        .where((t) {
          if (!t.isSettled) return false;
          if (_selectedCompanyId == null) return true;
          return t.companyId == _selectedCompanyId;
        })
        .fold(0.0, (sum, t) => sum + t.supplierEarning);

    final txOrderIds =
        _transactions.where((t) => t.isSettled).map((t) => t.orderId).toSet();
    final now = DateTime.now();
    final fromConfirmed = _orders.where((o) {
      if (o.status.toLowerCase() != 'confirmed') return false;
      if (_selectedCompanyId != null && o.companyId != _selectedCompanyId) {
        return false;
      }
      if (txOrderIds.contains(o.orderId)) return false;
      final d = o.confirmedAt ?? o.createdAt;
      return d.year == now.year && d.month == now.month;
    }).fold(0.0, (sum, o) {
      if (o.supplierEarning > 0) return sum + o.supplierEarning;
      return sum + (o.totalAmount * (1 - AppConstants.commissionRate));
    });

    return settledFromTx + fromConfirmed;
  }
  int get completedThisMonth => _orders.where((o) => o.status == 'confirmed' && o.createdAt.month == DateTime.now().month).length;

  double get averageRating {
    if (_ratings.isEmpty) return 0.0;
    final sum = _ratings.fold<double>(0, (acc, r) => acc + r.rating);
    return sum / _ratings.length;
  }

  void updateAuth(AuthViewModel auth) {
    final newUid = auth.user?.uid;
    if (_supplierUid == newUid) {
      if (newUid != null && auth.user != null) {
        _profile = auth.user;
        _status = auth.user!.status ?? 'pending';
        _rejectionReason = auth.user!.rejectionReason;
      }
      return;
    }

    _cancelSubscriptions();
    _supplierUid = newUid;
    _error = null;
    _companiesLoaded = false;
    _companiesLoadFailed = false;
    _selectedCompanyId = null;
    _companies = [];

    if (_supplierUid != null) {
      _profile = auth.user;
      _status = auth.user?.status ?? 'pending';
      _rejectionReason = auth.user?.rejectionReason;
      _ensureAuthAndLoad();
    }
    notifyListeners();
  }

  Future<void> retryInitialLoad() async {
    if (_supplierUid == null) return;
    _error = null;
    _companiesLoaded = false;
    _companiesLoadFailed = false;
    notifyListeners();
    await _ensureAuthAndLoad();
  }

  Future<void> _ensureAuthAndLoad() async {
    final uid = _supplierUid;
    if (uid == null) return;
    loadLinkedCompanies();
    loadInvitations();
    loadNotificationPreferences();
  }

  static const Map<String, bool> defaultNotificationPrefs = {
    'pushEnabled': true,
    'newOrders': true,
    'orderUpdates': true,
    'chatMessages': true,
    'ratings': true,
    'earnings': true,
  };

  Map<String, bool> _notificationPrefs =
      Map<String, bool>.from(defaultNotificationPrefs);
  bool _notificationPrefsLoaded = false;
  bool _notificationPrefsSaving = false;

  bool get notificationPrefsLoaded => _notificationPrefsLoaded;
  bool get notificationPrefsSaving => _notificationPrefsSaving;
  Map<String, bool> get notificationPrefs =>
      Map<String, bool>.unmodifiable(_notificationPrefs);

  Map<String, bool> _parseNotificationPrefs(dynamic raw) {
    if (raw is! Map) {
      return Map<String, bool>.from(defaultNotificationPrefs);
    }
    return {
      for (final entry in defaultNotificationPrefs.entries)
        entry.key: raw[entry.key] == true,
    };
  }

  Future<void> loadNotificationPreferences() async {
    if (_supplierUid == null) return;
    try {
      final snap = await _db.collection('users').doc(_supplierUid!).get();
      _notificationPrefs = _parseNotificationPrefs(
        snap.data()?['notificationPreferences'],
      );
      _notificationPrefsLoaded = true;
    } catch (e) {
      _error ??= e.toString();
      _notificationPrefsLoaded = true;
    }
    notifyListeners();
  }

  Future<String?> saveNotificationPreferences(Map<String, bool> prefs) async {
    if (_supplierUid == null) return 'Not signed in';
    _notificationPrefsSaving = true;
    notifyListeners();
    try {
      await _userRepo.updateUserDoc(_supplierUid!, {
        'notificationPreferences': prefs,
      });
      _notificationPrefs = Map<String, bool>.from(prefs);
      return null;
    } catch (e) {
      return e.toString();
    } finally {
      _notificationPrefsSaving = false;
      notifyListeners();
    }
  }

  void _cancelSubscriptions() {
    _statusSubscription?.cancel();
    _companiesSubscription?.cancel();
    _materialsSubscription?.cancel();
    _ordersSubscription?.cancel();
    _earningsSubscription?.cancel();
    _invitationsSubscription?.cancel();
    _ratingsSubscription?.cancel();
  }

  void _resetDashboardLoadingFlags() {
    _isDashboardLoading = true;
    _materialsInitialized = false;
    _ordersInitialized = false;
    _earningsInitialized = false;
    _ratingsInitialized = false;
  }

  void _onDashboardStreamError(String section, Object error) {
    _error = '$section: $error';
    if (section == 'materials') _materialsInitialized = true;
    if (section == 'orders') _ordersInitialized = true;
    if (section == 'earnings') _earningsInitialized = true;
    if (section == 'ratings') _ratingsInitialized = true;
    _checkDashboardReady();
    notifyListeners();
  }

  void _finishDashboardLoadingSoon() {
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (!_isDashboardLoading) return;
      _materialsInitialized = true;
      _ordersInitialized = true;
      _earningsInitialized = true;
      _ratingsInitialized = true;
      _isDashboardLoading = false;
      notifyListeners();
    });
  }

  void _finishCompaniesLoadingSoon() {
    Future.delayed(const Duration(milliseconds: 1500), () {
      if (_companiesLoaded) return;
      _companiesLoaded = true;
      notifyListeners();
    });
  }

  void _checkDashboardReady() {
    if (_materialsInitialized &&
        _ordersInitialized &&
        _earningsInitialized &&
        _ratingsInitialized) {
      if (_isDashboardLoading) {
        _isDashboardLoading = false;
        notifyListeners();
      }
    }
  }

  void watchStatus() {
    if (_supplierUid == null) return;
    _statusSubscription?.cancel();
    _statusSubscription = _userRepo.watchUserDoc(_supplierUid!).listen(
      (user) {
        _status = user.status ?? 'pending';
        _rejectionReason = user.rejectionReason;
        notifyListeners();
      },
      onError: (_) {
        // Non-blocking — dashboard still renders.
      },
    );
  }

  Future<List<CompanyModel>> _resolveCompaniesFallback() async {
    final uid = _supplierUid;
    if (uid == null) return [];

    final found = <CompanyModel>[];
    final seen = <String>{};

    void add(CompanyModel? company) {
      if (company != null && seen.add(company.id)) {
        found.add(company);
      }
    }

    final profileCompanyId = _profile?.companyId ?? '';
    if (profileCompanyId.isNotEmpty) {
      add(await _companyRepo.getCompanyById(profileCompanyId));
    }

    final companiesSnap = await _db.collection('companies').get();
    for (final companyDoc in companiesSnap.docs) {
      final link = await _db
          .collection('companies')
          .doc(companyDoc.id)
          .collection('suppliers')
          .doc(uid)
          .get();
      if (!link.exists) continue;

      final status =
          (link.data()?['status'] as String?)?.toLowerCase() ?? 'active';
      if (status != 'active' && status != 'approved') continue;

      add(await _companyRepo.getCompanyById(companyDoc.id));

      await _db
          .collection('suppliers')
          .doc(uid)
          .collection('companies')
          .doc(companyDoc.id)
          .set({
        'id': companyDoc.id,
        'status': 'active',
        'joinedAt': link.data()?['joinedAt'] ?? FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    }

    return found;
  }

  Future<void> loadLinkedCompanies() async {
    if (_supplierUid == null) {
      _companiesLoaded = true;
      notifyListeners();
      return;
    }
    _companiesSubscription?.cancel();
    _companiesLoadFailed = false;
    _finishCompaniesLoadingSoon();
    _companiesSubscription = _db
        .collection('suppliers')
        .doc(_supplierUid)
        .collection('companies')
        .where('status', isEqualTo: 'active')
        .snapshots()
        .listen((snap) async {
      var companyList = <CompanyModel>[];
      for (var doc in snap.docs) {
        try {
          final c = await _companyRepo.getCompanyById(doc.id);
          if (c != null) companyList.add(c);
        } catch (_) {
          // Skip companies we cannot read.
        }
      }
      if (companyList.isEmpty) {
        try {
          companyList = await _resolveCompaniesFallback();
        } catch (e) {
          _error ??= e.toString();
        }
      }
      _companies = companyList;
      _companiesLoaded = true;
      _companiesLoadFailed = false;
      if (_selectedCompanyId == null && _companies.isNotEmpty) {
        switchCompany(_companies.first.id);
      }
      notifyListeners();
    }, onError: (e) async {
      try {
        final fallback = await _resolveCompaniesFallback();
        _companies = fallback;
        _companiesLoaded = true;
        _companiesLoadFailed = fallback.isEmpty;
        _error = fallback.isEmpty ? e.toString() : null;
        if (_selectedCompanyId == null && _companies.isNotEmpty) {
          switchCompany(_companies.first.id);
        }
      } catch (_) {
        _companiesLoaded = true;
        _companiesLoadFailed = true;
        _error = e.toString();
      }
      notifyListeners();
    });
  }

  void switchCompany(String companyId) {
    if (_selectedCompanyId == companyId) return;
    _selectedCompanyId = companyId;
    _resetDashboardLoadingFlags();
    _finishDashboardLoadingSoon();
    loadMaterials(companyId);
    loadOrders(companyId, null);
    loadEarnings(monthKey());
    if (_supplierUid != null) {
      loadRatings(_supplierUid!, companyId);
    }
    notifyListeners();
  }

  // --- Invitations ---

  void loadInvitations() {
    if (_supplierUid == null) return;
    _invitationsSubscription?.cancel();
    _invitationsSubscription = _db.collection('invitations')
        .where('supplierUid', isEqualTo: _supplierUid)
        .snapshots()
        .listen((snap) {
      _invitations = snap.docs.map((d) => InvitationModel.fromMap(d.id, d.data())).toList();
      notifyListeners();
    }, onError: (e) {
      _error ??= e.toString();
      notifyListeners();
    });
  }

  Future<void> acceptInvitation(String inviteId, String companyId) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final batch = _db.batch();
      
      batch.update(_db.collection('invitations').doc(inviteId), {'status': 'accepted'});
      
      final supplierRef = _db.collection('suppliers').doc(_supplierUid);
      final companyRef = _db.collection('companies').doc(companyId);
      
      batch.set(supplierRef.collection('companies').doc(companyId), {
        'id': companyId,
        'status': 'active',
        'joinedAt': FieldValue.serverTimestamp(),
        'companyRating': 0,
        'onboardingComplete': false,
      });

      batch.set(companyRef.collection('suppliers').doc(_supplierUid), {
        'id': _supplierUid,
        'status': 'active',
        'joinedAt': FieldValue.serverTimestamp(),
      });

      batch.update(supplierRef, {'totalCompanies': FieldValue.increment(1)});

      await batch.commit();
      _selectedCompanyId = companyId;
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> rejectInvitation(String inviteId) async {
    await _db.collection('invitations').doc(inviteId).update({'status': 'rejected'});
  }

  // --- Materials ---

  Future<void> addMaterial(MaterialModel material, File? imageFile, String companyId) async {
    _isLoading = true;
    notifyListeners();
    try {
      String? imageUrl;
      if (imageFile != null) {
        imageUrl = await CloudinaryService.uploadImage(
          filePath: imageFile.path,
          folder: 'ratebridge/materials',
        );
        if (imageUrl == null) {
          _error = 'Image upload failed. Please try again.';
          return;
        }
      }
      final newMat = material.copyWith(profileImageUrl: imageUrl, supplierId: _supplierUid);
      
      final batch = _db.batch();
      final companyMatRef = _db.collection('companies').doc(companyId).collection('materials').doc(newMat.id);
      batch.set(companyMatRef, newMat.toMap());
      
      final globalMatRef = _db.collection('materials').doc(newMat.id);
      batch.set(globalMatRef, newMat.toMap());

      await batch.commit();
      await _materialRepo.recordInitialMaterialPrice(
        materialId: newMat.id,
        price: newMat.pricePerUnit,
        supplierUid: _supplierUid,
      );
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> updateMaterial(String matId, Map<String, dynamic> data, File? imageFile, String companyId) async {
    _isLoading = true;
    notifyListeners();
    try {
      if (imageFile != null) {
        final imageUrl = await CloudinaryService.uploadImage(
          filePath: imageFile.path,
          folder: 'ratebridge/materials',
        );
        if (imageUrl == null) {
          _error = 'Image upload failed. Please try again.';
          return;
        }
        data['profileImageUrl'] = imageUrl;
      }
      
      if (data.containsKey('pricePerUnit')) {
        final doc = await _db.collection('materials').doc(matId).get();
        final oldPrice = (doc.data()?['pricePerUnit'] as num?)?.toDouble() ?? 0.0;
        final newPrice = (data['pricePerUnit'] as num).toDouble();
        if (oldPrice != newPrice) {
          await _materialRepo.archiveMaterialPriceChange(
            materialId: matId,
            previousPrice: oldPrice,
            newPrice: newPrice,
            supplierUid: _supplierUid,
          );
        }
      }
      
      await _db.collection('materials').doc(matId).update(data);
      await _db.collection('companies').doc(companyId).collection('materials').doc(matId).update(data);
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> deleteMaterial(String matId, String companyId) async {
    _isLoading = true;
    notifyListeners();
    try {
      await _materialRepo.removeMaterial(matId);
      await _db.collection('companies').doc(companyId).collection('materials').doc(matId).delete();
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadMaterials(String companyId) async {
    if (_supplierUid == null) {
      _materialsInitialized = true;
      _checkDashboardReady();
      notifyListeners();
      return;
    }
    _materialsSubscription?.cancel();
    _materialsSubscription = _db
        .collection('companies')
        .doc(companyId)
        .collection('materials')
        .where('supplierId', isEqualTo: _supplierUid)
        .snapshots()
        .listen((snap) {
      _materials = snap.docs.map((d) {
        final data = Map<String, dynamic>.from(d.data());
        data.putIfAbsent('id', () => d.id);
        return MaterialModel.fromMap(data);
      }).toList();
      _materialsInitialized = true;
      _checkDashboardReady();
      notifyListeners();
    }, onError: (e) => _onDashboardStreamError('materials', e));
  }

  // --- Orders ---

  Future<void> loadOrders(String companyId, String? statusFilter) async {
    if (_supplierUid == null) {
      _ordersInitialized = true;
      _checkDashboardReady();
      notifyListeners();
      return;
    }
    _ordersSubscription?.cancel();
    _ordersSubscription = _orderRepo.getOrdersForSupplier(_supplierUid!).listen(
      (data) {
        _orders = data.where((o) => o.companyId == companyId).toList();
        _ordersInitialized = true;
        _checkDashboardReady();
        notifyListeners();
      },
      onError: (e) => _onDashboardStreamError('orders', e),
    );
  }

  Future<void> acceptOrder(String orderId, String companyId) async {
    _isLoading = true;
    notifyListeners();
    try {
      final order = _orders.firstWhere(
        (o) => o.orderId == orderId,
        orElse: () => throw StateError('Order not found'),
      );
      await _orderRepo.updateStatus(orderId, companyId, 'accepted');
      await _notificationService.notifyOrderAccepted(
        fieldUserUid: order.fieldUserUid,
        orderId: orderId,
        companyId: companyId,
        materialName: order.materialName,
        supplierName: order.supplierName,
      );
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> rejectOrder(String orderId, String companyId, String reason) async {
    _isLoading = true;
    notifyListeners();
    try {
      final order = _orders.firstWhere(
        (o) => o.orderId == orderId,
        orElse: () => throw StateError('Order not found'),
      );
      await _orderRepo.updateStatus(orderId, companyId, 'rejected', reason: reason);
      await _notificationService.notifyOrderRejected(
        fieldUserUid: order.fieldUserUid,
        orderId: orderId,
        companyId: companyId,
        materialName: order.materialName,
        supplierName: order.supplierName,
        reason: reason,
      );
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> markDelivered(String orderId, String companyId) async {
    _isLoading = true;
    notifyListeners();
    try {
      final order = _orders.firstWhere(
        (o) => o.orderId == orderId,
        orElse: () => throw StateError('Order not found'),
      );
      await _orderRepo.updateStatus(orderId, companyId, 'delivered', deliveredAt: DateTime.now());
      await _notificationService.notifyOrderDelivered(
        fieldUserUid: order.fieldUserUid,
        orderId: orderId,
        companyId: companyId,
        materialName: order.materialName,
        supplierName: order.supplierName,
      );
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // --- Onboarding ---

  Future<void> completeCompanyOnboarding(String companyId, Map<String, dynamic> details) async {
    _isLoading = true;
    notifyListeners();
    try {
      await _db.collection('suppliers').doc(_supplierUid)
          .collection('companies').doc(companyId)
          .update({...details, 'onboardingComplete': true});
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // --- Profile & Earnings ---

  Future<void> loadEarnings(String month) async {
    if (_supplierUid == null) {
      _earningsInitialized = true;
      _checkDashboardReady();
      notifyListeners();
      return;
    }
    _earningsSubscription?.cancel();
    try {
      _earningsSubscription = _transactionRepo.watchSupplierEarnings(_supplierUid!, month).listen(
        (txs) {
          _transactions = txs;
          totalEarnings = txs.fold(0.0, (sum, tx) => sum + tx.totalAmount);
          netEarnings = txs.fold(0.0, (sum, tx) => sum + tx.supplierEarning);
          _earningsInitialized = true;
          _checkDashboardReady();
          notifyListeners();
        },
        onError: (e) => _onDashboardStreamError('earnings', e),
      );
      final summary = await _transactionRepo.getMonthlyEarningsSummary(_supplierUid!, 6);
      _monthlyEarnings = summary.reversed.toList();
      _monthlyChart = summary.map((e) => {'month': e.month, 'amount': e.net}).toList();
    } catch (e) {
      _error = e.toString();
      _earningsInitialized = true;
      _checkDashboardReady();
      notifyListeners();
    }
  }

  Future<void> changeMonth(String month) async {
    await loadEarnings(month);
  }

  Future<void> loadProfile() async {
    if (_supplierUid == null) return;
    if (_profile != null && _profile!.uid == _supplierUid) {
      notifyListeners();
      return;
    }
    final cached = _userRepo.cachedUser;
    if (cached != null && cached.uid == _supplierUid) {
      _profile = cached;
      notifyListeners();
      return;
    }
    try {
      _profile = await _userRepo.getUserDoc(_supplierUid!);
    } catch (e) {
      _error ??= e.toString();
    }
    notifyListeners();
  }

  Future<void> updateProfile(Map<String, dynamic> fields) async {
    if (_supplierUid == null) return;
    await _userRepo.updateUserDoc(_supplierUid!, fields);
    _profile = _userRepo.cachedUser ?? _profile;
    notifyListeners();
  }

  Future<void> submitAppeal(String message, File? file, String? phone) async {
    _isLoading = true;
    notifyListeners();
    try {
      String? imageUrl;
      if (file != null) {
        imageUrl = await _storageService.uploadFile(file: file, path: 'appeals/$_supplierUid');
      }
      await _db.collection('appeals').add({
        'supplierUid': _supplierUid,
        'message': message,
        'phone': phone,
        'imageUrl': imageUrl,
        'createdAt': FieldValue.serverTimestamp(),
        'status': 'pending',
      });
      _appealSubmitted = true;
    } catch (e) {
      _error = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadCompanyDirectory() async {
    _isLoading = true;
    notifyListeners();
    try {
      _companies = await _companyRepo.getAllCompanies();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> searchCompanies(String query) async {
    final all = await _companyRepo.getAllCompanies();
    _companies = all.where((c) => c.name.toLowerCase().contains(query.toLowerCase())).toList();
    notifyListeners();
  }

  Future<void> sendJoinRequest(String companyId, String message) async {
    await _db.collection('joinRequests').add({
      'companyId': companyId,
      'supplierUid': _supplierUid,
      'message': message,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
      'supplierName': _profile?.name ?? 'Supplier',
    });
  }

  Future<void> loadRatings(String supplierUid, String companyId) async {
    _ratingsSubscription?.cancel();
    _ratingsSubscription = _db
        .collection('ratings')
        .where('supplierUid', isEqualTo: supplierUid)
        .snapshots()
        .listen((snap) {
      _ratings = snap.docs.map((d) => RatingModel.fromMap(d.id, d.data())).toList();
      _ratingsInitialized = true;
      _checkDashboardReady();
      notifyListeners();
    }, onError: (e) => _onDashboardStreamError('ratings', e));
  }

  String? companyNameFor(String companyId) {
    try {
      return _companies.firstWhere((c) => c.id == companyId).name;
    } catch (_) {
      return null;
    }
  }

  void filterRatingsByMaterial(String name) {
    if (name == 'All') {
      loadRatings(_supplierUid!, _selectedCompanyId!);
    } else {
      _ratings = _ratings.where((r) => r.materialName == name).toList();
      notifyListeners();
    }
  }

  Future<void> loadDashboard() async {
    if (_supplierUid == null || _selectedCompanyId == null) return;
    _error = null;
    _resetDashboardLoadingFlags();
    notifyListeners();
    _finishDashboardLoadingSoon();
    loadMaterials(_selectedCompanyId!);
    loadOrders(_selectedCompanyId!, null);
    loadEarnings(monthKey());
    loadRatings(_supplierUid!, _selectedCompanyId!);
  }

  @override
  void dispose() {
    _cancelSubscriptions();
    super.dispose();
  }
}
