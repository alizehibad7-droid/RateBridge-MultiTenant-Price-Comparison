class MaterialListing {
  final String id;
  final String materialName;
  final String supplierName;
  final String supplierId;
  final double pricePerUnit;
  final String unit;
  final double supplierRating;
  final int reviewCount;
  final int stock;
  final String category;
  final String? city;
  final String? phone;
  final DateTime? priceUpdatedAt;
  final bool isAnomaly;
  final bool isBestValue;

  MaterialListing({
    required this.id,
    required this.materialName,
    required this.supplierName,
    required this.supplierId,
    required this.pricePerUnit,
    required this.unit,
    this.supplierRating = 0.0,
    this.reviewCount = 0,
    this.stock = 0,
    required this.category,
    this.city,
    this.phone,
    this.priceUpdatedAt,
    this.isAnomaly = false,
    this.isBestValue = false,
  });

  MaterialListing copyWith({
    String? id,
    String? materialName,
    String? supplierName,
    String? supplierId,
    double? pricePerUnit,
    String? unit,
    double? supplierRating,
    int? reviewCount,
    int? stock,
    String? category,
    String? city,
    String? phone,
    DateTime? priceUpdatedAt,
    bool? isAnomaly,
    bool? isBestValue,
  }) {
    return MaterialListing(
      id: id ?? this.id,
      materialName: materialName ?? this.materialName,
      supplierName: supplierName ?? this.supplierName,
      supplierId: supplierId ?? this.supplierId,
      pricePerUnit: pricePerUnit ?? this.pricePerUnit,
      unit: unit ?? this.unit,
      supplierRating: supplierRating ?? this.supplierRating,
      reviewCount: reviewCount ?? this.reviewCount,
      stock: stock ?? this.stock,
      category: category ?? this.category,
      city: city ?? this.city,
      phone: phone ?? this.phone,
      priceUpdatedAt: priceUpdatedAt ?? this.priceUpdatedAt,
      isAnomaly: isAnomaly ?? this.isAnomaly,
      isBestValue: isBestValue ?? this.isBestValue,
    );
  }
}
