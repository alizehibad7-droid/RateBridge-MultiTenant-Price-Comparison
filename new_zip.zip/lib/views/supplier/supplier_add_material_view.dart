// MVVM: View — no business logic
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../theme/supplier_theme.dart';
import '../../models/category_model.dart';
import '../../utils/app_theme.dart';
import '../../utils/chat_image_utils.dart';
import '../../viewmodels/auth_viewmodel.dart';
import '../../viewmodels/material_viewmodel.dart';

class SupplierAddMaterialView extends StatefulWidget {
  const SupplierAddMaterialView({super.key});

  @override
  State<SupplierAddMaterialView> createState() => _SupplierAddMaterialViewState();
}

class _SupplierAddMaterialViewState extends State<SupplierAddMaterialView> {
  static const _stockStatuses = [
    'Available',
    'Limited Stock',
    'Out of Stock',
  ];
  static const _deliveryTimes = [
    'Same day',
    '24 hours',
    '2-3 days',
    '1 week+',
  ];

  final _formKey = GlobalKey<FormState>();
  final _categoryFieldKey = GlobalKey<FormFieldState<String>>();
  final _nameController = TextEditingController();
  final _priceController = TextEditingController();
  final _brandController = TextEditingController();
  final _gradeController = TextEditingController();
  final _minOrderController = TextEditingController();

  String? _selectedCategoryId;
  String? _selectedBrand;
  String? _selectedGrade;
  String _stockStatus = 'Available';
  String? _deliveryTime;
  XFile? _imageXFile;
  Uint8List? _imagePreviewBytes;
  bool _nameManuallyEdited = false;
  bool _categoriesLoaded = false;

  InputDecoration get _fieldDecoration => SupplierTheme.fieldDecoration();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadCategories());
  }

  Future<void> _loadCategories() async {
    final materialVM = context.read<MaterialViewModel>();
    materialVM.resetAddMaterialForm();
    setState(() {
      _selectedCategoryId = null;
      _categoriesLoaded = false;
    });
    await materialVM.loadCategories();
    if (!mounted) return;
    setState(() => _categoriesLoaded = true);
  }

  Future<void> _pickCategory(MaterialViewModel materialVM) async {
    final categories = materialVM.categories;
    if (categories.isEmpty) return;

    final pickedId = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: FieldColors.surfaceWhite,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(FieldRadius.card)),
      ),
      builder: (ctx) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                child: Text(
                  'Select category',
                  style: AppTextStyles.h3,
                ),
              ),
              const Divider(height: 1),
              Flexible(
                child: ListView.separated(
                  shrinkWrap: true,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  itemCount: categories.length,
                  separatorBuilder: (_, __) => const Divider(
                    height: 1,
                    indent: 20,
                    endIndent: 20,
                  ),
                  itemBuilder: (context, index) {
                    final category = categories[index];
                    final isSelected = category.id == _selectedCategoryId;
                    return ListTile(
                      title: Text(
                        category.name,
                        style: AppTextStyles.body.copyWith(
                          fontWeight:
                              isSelected ? FontWeight.w700 : FontWeight.w500,
                        ),
                      ),
                      subtitle: category.unit.isNotEmpty
                          ? Text(
                              'Unit: ${category.unit}',
                              style: AppTextStyles.caption,
                            )
                          : null,
                      trailing: isSelected
                          ? const Icon(
                              Icons.check_circle,
                              color: FieldColors.accentAmber,
                            )
                          : null,
                      onTap: () => Navigator.pop(ctx, category.id),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );

    if (pickedId == null || !mounted) return;

    setState(() {
      _selectedCategoryId = pickedId;
      _selectedBrand = null;
      _selectedGrade = null;
      _brandController.clear();
      _gradeController.clear();
      _nameManuallyEdited = false;
      _nameController.clear();
    });
    materialVM.onCategorySelected(pickedId);
    _categoryFieldKey.currentState?.didChange(pickedId);
    _updateAutoName(materialVM);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    _brandController.dispose();
    _gradeController.dispose();
    _minOrderController.dispose();
    super.dispose();
  }

  String? get _brandValue {
    if (_selectedBrand != null && _selectedBrand!.isNotEmpty) {
      return _selectedBrand;
    }
    final text = _brandController.text.trim();
    return text.isEmpty ? null : text;
  }

  String? get _gradeValue {
    if (_selectedGrade != null && _selectedGrade!.isNotEmpty) {
      return _selectedGrade;
    }
    final text = _gradeController.text.trim();
    return text.isEmpty ? null : text;
  }

  String? _validCategoryValue(MaterialViewModel materialVM) {
    if (_selectedCategoryId == null) return null;
    final exists =
        materialVM.categories.any((c) => c.id == _selectedCategoryId);
    return exists ? _selectedCategoryId : null;
  }

  CategoryModel? _selectedCategory(MaterialViewModel materialVM) {
    final id = _validCategoryValue(materialVM);
    if (id == null) return null;
    try {
      return materialVM.categories.firstWhere((c) => c.id == id);
    } catch (_) {
      return null;
    }
  }

  void _updateAutoName(MaterialViewModel materialVM) {
    if (_nameManuallyEdited) return;
    final category = materialVM.selectedCategory;
    if (category == null) return;

    final parts = <String>[
      if (_brandValue != null) _brandValue!,
      category.name,
      if (_gradeValue != null) _gradeValue!,
    ];
    _nameController.text = parts.join(' ');
  }

  Future<void> _pickImage() async {
    final source = await ChatImageUtils.showSourceSheet(context);
    if (source == null) return;

    final picker = ImagePicker();
    final picked = await picker.pickImage(
      source: source,
      maxWidth: 1200,
      imageQuality: 80,
    );
    if (picked == null || !mounted) return;

    final bytes = await picked.readAsBytes();
    setState(() {
      _imageXFile = picked;
      _imagePreviewBytes = bytes;
    });
  }

  Widget _buildCategoryField(MaterialViewModel materialVM) {
    if (!_categoriesLoaded || materialVM.isLoadingCategories) {
      return Container(
        padding: const EdgeInsets.all(20),
        decoration: SupplierTheme.cardDecoration(),
        child: Row(
          children: [
            const SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(strokeWidth: 2.5),
            ),
            const SizedBox(width: 16),
            Text('Loading categories…', style: AppTextStyles.bodyMuted),
          ],
        ),
      );
    }

    if (materialVM.categories.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: SupplierTheme.cardDecoration(
          borderColor: FieldColors.statusWarning.withValues(alpha: 0.35),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.category_outlined, color: FieldColors.statusWarning),
            const SizedBox(height: 12),
            Text(
              'No categories available',
              style: AppTextStyles.h3.copyWith(fontSize: 15),
            ),
            const SizedBox(height: 6),
            Text(
              'Please ask admin to add categories first.',
              style: AppTextStyles.bodyMuted,
            ),
          ],
        ),
      );
    }

    return FormField<String>(
      key: _categoryFieldKey,
      initialValue: _validCategoryValue(materialVM),
      validator: (v) => v == null ? 'Please select a category' : null,
      builder: (fieldState) {
        final selected = _selectedCategory(materialVM);
        final decoration = _fieldDecoration.copyWith(
          labelText: 'Category',
          errorText: fieldState.errorText,
        );

        return InkWell(
          onTap: () => _pickCategory(materialVM),
          borderRadius: BorderRadius.circular(FieldRadius.input),
          child: InputDecorator(
            decoration: decoration,
            isEmpty: selected == null,
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    selected?.name ?? 'Select a category',
                    style: selected == null
                        ? AppTextStyles.bodyMuted
                        : AppTextStyles.body,
                  ),
                ),
                const Icon(
                  Icons.keyboard_arrow_down_rounded,
                  color: FieldColors.textSecondary,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final materialVM = context.watch<MaterialViewModel>();
    final authVM = context.watch<AuthViewModel>();
    final category = materialVM.selectedCategory;
    final brands = category?.brands ?? const <String>[];
    final grades = category?.grades ?? const <String>[];
    final hasCategory = category != null;

    return Scaffold(
      backgroundColor: FieldColors.screenBackground,
      appBar: const SupplierAppBar(title: 'Add Material'),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            _buildCategoryField(materialVM),
            const SizedBox(height: 16),
            if (hasCategory) ...[
              if (brands.isNotEmpty)
                DropdownButtonFormField<String>(
                  decoration: _fieldDecoration.copyWith(labelText: 'Brand'),
                  isExpanded: true,
                  value: _selectedBrand,
                  items: brands
                      .map(
                        (b) => DropdownMenuItem(
                          value: b,
                          child: Text(b, style: AppTextStyles.body),
                        ),
                      )
                      .toList(),
                  onChanged: (val) {
                    setState(() => _selectedBrand = val);
                    _updateAutoName(materialVM);
                  },
                )
              else
                TextFormField(
                  controller: _brandController,
                  decoration: _fieldDecoration.copyWith(labelText: 'Brand'),
                  style: AppTextStyles.body,
                  onChanged: (_) => _updateAutoName(materialVM),
                ),
              const SizedBox(height: 16),
              if (grades.isNotEmpty)
                DropdownButtonFormField<String>(
                  decoration: _fieldDecoration.copyWith(labelText: 'Grade'),
                  isExpanded: true,
                  value: _selectedGrade,
                  items: grades
                      .map(
                        (g) => DropdownMenuItem(
                          value: g,
                          child: Text(g, style: AppTextStyles.body),
                        ),
                      )
                      .toList(),
                  onChanged: (val) {
                    setState(() => _selectedGrade = val);
                    _updateAutoName(materialVM);
                  },
                )
              else
                TextFormField(
                  controller: _gradeController,
                  decoration: _fieldDecoration.copyWith(labelText: 'Grade'),
                  style: AppTextStyles.body,
                  onChanged: (_) => _updateAutoName(materialVM),
                ),
              const SizedBox(height: 16),
            ],
            TextFormField(
              controller: _nameController,
              readOnly: !hasCategory,
              decoration: _fieldDecoration.copyWith(
                labelText: 'Material Name',
                hintText: hasCategory
                    ? 'e.g. DG Khan Cement OPC'
                    : 'Select a category first',
                fillColor: hasCategory
                    ? FieldColors.surfaceWhite
                    : FieldColors.screenBackground,
              ),
              style: AppTextStyles.body,
              validator: (v) =>
                  v == null || v.trim().isEmpty ? 'Required' : null,
              onChanged: (_) => _nameManuallyEdited = true,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _priceController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: _fieldDecoration.copyWith(
                labelText: 'Price',
                prefixText: 'Rs. ',
              ),
              style: AppTextStyles.body,
              validator: (v) =>
                  v == null || v.trim().isEmpty ? 'Required' : null,
            ),
            const SizedBox(height: 16),
            TextFormField(
              key: ValueKey(category?.unit ?? 'no-unit'),
              initialValue: category?.unit ?? '',
              decoration: _fieldDecoration.copyWith(
                labelText: 'Unit',
                fillColor: FieldColors.screenBackground,
                helperText: hasCategory
                    ? 'Set by admin for this category'
                    : 'Select a category to see unit',
              ),
              readOnly: true,
              enableInteractiveSelection: false,
              style: AppTextStyles.body.copyWith(color: FieldColors.textMuted),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              decoration: _fieldDecoration.copyWith(labelText: 'Stock Status'),
              isExpanded: true,
              value: _stockStatus,
              items: _stockStatuses
                  .map(
                    (s) => DropdownMenuItem(
                      value: s,
                      child: Text(s, style: AppTextStyles.body),
                    ),
                  )
                  .toList(),
              onChanged: (val) {
                if (val != null) setState(() => _stockStatus = val);
              },
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _minOrderController,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: _fieldDecoration.copyWith(
                labelText: 'Minimum Order Quantity (optional)',
              ),
              style: AppTextStyles.body,
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              decoration: _fieldDecoration.copyWith(
                labelText: 'Delivery Time (optional)',
              ),
              isExpanded: true,
              value: _deliveryTime,
              items: [
                DropdownMenuItem<String>(
                  value: null,
                  child: Text('Not specified', style: AppTextStyles.bodyMuted),
                ),
                ..._deliveryTimes.map(
                  (d) => DropdownMenuItem(
                    value: d,
                    child: Text(d, style: AppTextStyles.body),
                  ),
                ),
              ],
              onChanged: (val) => setState(() => _deliveryTime = val),
            ),
            const SizedBox(height: 32),
            Text('PHOTO (OPTIONAL)', style: AppTextStyles.label),
            const SizedBox(height: 12),
            InkWell(
              onTap: _pickImage,
              borderRadius: BorderRadius.circular(AppRadius.lg),
              child: Container(
                height: 120,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: FieldColors.screenBackground,
                  borderRadius: BorderRadius.circular(AppRadius.lg),
                  border: Border.all(color: FieldColors.borderSubtle),
                ),
                child: _imagePreviewBytes == null
                    ? const Icon(
                        Icons.add_a_photo_outlined,
                        color: FieldColors.textSecondary,
                      )
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(AppRadius.lg),
                        child: Image.memory(
                          _imagePreviewBytes!,
                          fit: BoxFit.cover,
                          width: double.infinity,
                          height: 120,
                          gaplessPlayback: true,
                        ),
                      ),
              ),
            ),
            if (materialVM.error != null) ...[
              const SizedBox(height: 16),
              Text(
                materialVM.error!,
                style: AppTextStyles.body.copyWith(color: FieldColors.statusDanger),
              ),
            ],
            const SizedBox(height: 48),
            ElevatedButton(
              onPressed: materialVM.isLoading || materialVM.categories.isEmpty
                  ? null
                  : () async {
                      if (!_formKey.currentState!.validate()) return;

                      materialVM.resetSuccess();
                      await materialVM.addMaterial(
                        {
                          'name': _nameController.text.trim(),
                          'price': _priceController.text.trim(),
                          'brand': _brandValue ?? '',
                          'grade': _gradeValue ?? '',
                          'stockStatus': _stockStatus,
                          'minOrderQuantity': _minOrderController.text.trim(),
                          'deliveryTime': _deliveryTime,
                          'supplierName': authVM.user?.name ?? '',
                        },
                        _imageXFile,
                        authVM.user?.companyId ?? '',
                        authVM.user?.uid ?? '',
                      );
                      if (!mounted) return;
                      if (materialVM.isSuccess) {
                        Navigator.pop(context);
                      }
                    },
              child: materialVM.isLoading
                  ? const SizedBox(
                      height: 22,
                      width: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Colors.white,
                      ),
                    )
                  : const Text('SAVE MATERIAL'),
            ),
          ],
        ),
      ),
    );
  }
}
