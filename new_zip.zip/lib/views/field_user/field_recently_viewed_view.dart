import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../constants/route_names.dart';
import '../../models/material_model.dart';
import '../../repositories/material_repository.dart';
import '../../services/recently_viewed_service.dart';
import '../../theme/field_theme.dart';
import 'widgets/field_material_card.dart';
import 'widgets/field_material_grid_skeleton.dart';

class FieldRecentlyViewedView extends StatefulWidget {
  const FieldRecentlyViewedView({super.key});

  @override
  State<FieldRecentlyViewedView> createState() =>
      _FieldRecentlyViewedViewState();
}

class _FieldRecentlyViewedViewState extends State<FieldRecentlyViewedView> {
  List<MaterialModel> _materials = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    setState(() => _loading = true);

    final ids = await context.read<RecentlyViewedService>().readRecentIds();
    if (!mounted) return;

    if (ids.isEmpty) {
      setState(() {
        _materials = [];
        _loading = false;
      });
      return;
    }

    final fetched =
        await context.read<MaterialRepository>().getMaterialsByIds(ids);
    final byId = {for (final material in fetched) material.id: material};

    if (!mounted) return;
    setState(() {
      _materials = ids
          .map((id) => byId[id])
          .whereType<MaterialModel>()
          .toList();
      _loading = false;
    });
  }

  Future<void> _clearHistory() async {
    await context.read<RecentlyViewedService>().wipeHistory();
    if (!mounted) return;
    setState(() => _materials = []);
  }

  void _openCompare(MaterialModel material) {
    context.read<RecentlyViewedService>().persistView(material.id);
    context.push(
      RouteNames.fieldCompare.replaceFirst(
        ':materialId',
        Uri.encodeComponent(material.name),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: FieldTheme.theme,
      child: Scaffold(
        backgroundColor: FieldColors.screenBackground,
        appBar: FieldAppBar(
          title: 'Recently Viewed',
          actions: [
            if (_materials.isNotEmpty)
              TextButton(
                onPressed: _clearHistory,
                child: Text(
                  'Clear',
                  style: FieldTypography.bodyMedium.copyWith(
                    color: FieldColors.accentAmber,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
          ],
        ),
        body: _loading && _materials.isEmpty
            ? const FieldMaterialGridSkeleton()
            : _materials.isEmpty
                ? const _RecentlyViewedEmptyState()
                : RefreshIndicator(
                    color: FieldColors.primaryNavy,
                    onRefresh: _load,
                    child: GridView.builder(
                      padding: const EdgeInsets.all(FieldSpacing.lg),
                      physics: const AlwaysScrollableScrollPhysics(
                        parent: BouncingScrollPhysics(),
                      ),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: FieldSpacing.md,
                        crossAxisSpacing: FieldSpacing.md,
                        childAspectRatio: 0.82,
                      ),
                      itemCount: _materials.length,
                      itemBuilder: (context, index) {
                        final material = _materials[index];
                        return FieldMaterialCard(
                          material: material,
                          onTap: () => _openCompare(material),
                        );
                      },
                    ),
                  ),
      ),
    );
  }
}

class _RecentlyViewedEmptyState extends StatelessWidget {
  const _RecentlyViewedEmptyState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(FieldSpacing.xl),
        child: Text(
          'Materials you browse will appear here',
          style: FieldTypography.bodyLarge.copyWith(
            color: FieldColors.textSecondary,
          ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
